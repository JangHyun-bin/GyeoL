from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.build import run_check


def main() -> int:
    return run_check()


if __name__ == "__main__":
    raise SystemExit(main())
